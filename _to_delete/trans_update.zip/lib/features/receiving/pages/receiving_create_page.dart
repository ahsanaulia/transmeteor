import 'package:flutter/material.dart';

import '../../../core/theme/app_colors.dart';
import '../../../core/widgets/widgets.dart';
import '../../../models/sender_model.dart';
import '../../../services/receiving_service.dart';
import '../../../services/sender_service.dart';

class ReceivingCreatePage extends StatefulWidget {
  const ReceivingCreatePage({super.key});

  @override
  State<ReceivingCreatePage> createState() => _ReceivingCreatePageState();
}

class _ReceivingCreatePageState extends State<ReceivingCreatePage> {
  // ============================================================
  // CONTROLLERS
  // ============================================================

  final _senderController = TextEditingController();
  final _receiverNameController = TextEditingController();
  final _receiverPhoneController = TextEditingController();
  final _destinationController = TextEditingController();
  final _destinationAddressController = TextEditingController();
  final _routeController = TextEditingController();

  // ============================================================
  // STATE
  // ============================================================

  SenderModel? _selectedSender;

  bool _isSaving = false;

  String? _errorMessage;

  @override
  void dispose() {
    _senderController.dispose();
    _receiverNameController.dispose();
    _receiverPhoneController.dispose();
    _destinationController.dispose();
    _destinationAddressController.dispose();
    _routeController.dispose();

    super.dispose();
  }

  // ============================================================
  // SELECT SENDER
  // ============================================================
  //
  // NOTE: pencarian & debounce sekarang ditangani oleh SearchPickField
  // (core/widgets/search_pick_field.dart) -- halaman ini cukup
  // menyediakan fungsi pencarian & callback pilih/hapus.

  void _selectSender(SenderModel sender) {
    FocusScope.of(context).unfocus();

    setState(() {
      _selectedSender = sender;
      _senderController.text = sender.name;
      _errorMessage = null;
    });
  }

  void _clearSender() {
    setState(() {
      _selectedSender = null;
      _senderController.clear();
    });
  }

  // ============================================================
  // CREATE NEW SENDER
  // ============================================================

  Future<void> _showCreateSenderDialog() async {
    final nameController = TextEditingController(
      text: _senderController.text.trim(),
    );
    final phoneController = TextEditingController();
    final addressController = TextEditingController();

    final result = await showDialog<SenderModel>(
      context: context,
      builder: (dialogContext) {
        bool isCreating = false;

        return StatefulBuilder(
          builder: (context, setDialogState) {
            Future<void> createSender() async {
              final name = nameController.text.trim();

              if (name.isEmpty) {
                ScaffoldMessenger.of(dialogContext).showSnackBar(
                  const SnackBar(
                    content: Text(
                      'Nama pengirim wajib diisi.',
                    ),
                  ),
                );
                return;
              }

              setDialogState(() {
                isCreating = true;
              });

              try {
                final sender = await SenderService.createSender(
                  name: name,
                  phone: phoneController.text.trim().isEmpty
                      ? null
                      : phoneController.text.trim(),
                  address: addressController.text.trim().isEmpty
                      ? null
                      : addressController.text.trim(),
                );

                if (!dialogContext.mounted) return;

                Navigator.of(dialogContext).pop(sender);
              } catch (e) {
                if (!dialogContext.mounted) return;

                setDialogState(() {
                  isCreating = false;
                });

                ScaffoldMessenger.of(dialogContext).showSnackBar(
                  SnackBar(
                    content: Text(
                      'Gagal membuat pengirim: $e',
                    ),
                  ),
                );
              }
            }

            return AlertDialog(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(24),
              ),
              title: const Row(
                children: [
                  Icon(
                    Icons.person_add_alt_1_rounded,
                    color: AppColors.blue,
                  ),
                  SizedBox(width: 10),
                  Text('Pengirim Baru'),
                ],
              ),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    AppTextField(
                      controller: nameController,
                      label: 'Nama Pengirim',
                      icon: Icons.business_rounded,
                      borderRadius: 14,
                    ),
                    const SizedBox(height: 14),
                    AppTextField(
                      controller: phoneController,
                      label: 'No. HP',
                      icon: Icons.phone_rounded,
                      keyboardType: TextInputType.phone,
                      borderRadius: 14,
                    ),
                    const SizedBox(height: 14),
                    AppTextField(
                      controller: addressController,
                      label: 'Alamat',
                      icon: Icons.location_on_outlined,
                      maxLines: 3,
                      borderRadius: 14,
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton(
                  onPressed: isCreating
                      ? null
                      : () {
                          Navigator.of(dialogContext).pop();
                        },
                  child: const Text('Batal'),
                ),
                FilledButton.icon(
                  onPressed: isCreating ? null : createSender,
                  icon: isCreating
                      ? const SizedBox(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: Colors.white,
                          ),
                        )
                      : const Icon(
                          Icons.check_rounded,
                        ),
                  label: const Text('Simpan'),
                ),
              ],
            );
          },
        );
      },
    );

    nameController.dispose();
    phoneController.dispose();
    addressController.dispose();

    if (result == null || !mounted) return;

    _selectSender(result);
  }

  // ============================================================
  // SAVE RECEIVING
  // ============================================================

  Future<void> _saveReceiving() async {
    FocusScope.of(context).unfocus();

    if (_selectedSender == null) {
      setState(() {
        _errorMessage =
            'Silakan pilih atau buat pengirim terlebih dahulu.';
      });
      return;
    }

    final receiverName =
        _receiverNameController.text.trim();

    final destination =
        _destinationController.text.trim();

    if (receiverName.isEmpty) {
      setState(() {
        _errorMessage =
            'Nama penerima wajib diisi.';
      });
      return;
    }

    if (destination.isEmpty) {
      setState(() {
        _errorMessage =
            'Tujuan pengiriman wajib diisi.';
      });
      return;
    }

    setState(() {
      _isSaving = true;
      _errorMessage = null;
    });

    try {
      /*
       * NOTE:
       *
       * packageTypeId dan receivedBy merupakan field wajib
       * pada ReceivingService.
       *
       * Untuk sementara page ini menggunakan placeholder
       * sampai UI pemilihan Package Type dan identitas
       * employee yang login kita sambungkan.
       */

      const packageTypeId = '';

      const receivedBy = '';

      if (packageTypeId.isEmpty) {
        throw Exception(
          'Package Type belum dipilih.',
        );
      }

      if (receivedBy.isEmpty) {
        throw Exception(
          'Employee penerima belum tersedia.',
        );
      }

      final receiving =
          await ReceivingService.createReceiving(
        senderId: _selectedSender!.id,
        receiverName: receiverName,
        receiverPhone:
            _receiverPhoneController.text.trim().isEmpty
                ? null
                : _receiverPhoneController.text.trim(),
        packageTypeId: packageTypeId,
        destination: destination,
        destinationAddress:
            _destinationAddressController.text.trim().isEmpty
                ? null
                : _destinationAddressController.text.trim(),
        receivedBy: receivedBy,
        route: _routeController.text.trim().isEmpty
            ? null
            : _routeController.text.trim(),
      );

      if (!mounted) return;

      await SuccessResultDialog.show(
        context,
        title: 'Penerimaan Berhasil',
        message: 'Nomor resi berhasil dibuat oleh sistem.',
        valueLabel: 'NOMOR RESI',
        value: receiving.receiptNumber,
        onDone: () {
          Navigator.of(context).pop();
          Navigator.of(context).pop();
        },
      );
    } catch (e) {
      if (!mounted) return;

      setState(() {
        _errorMessage =
            e.toString().replaceFirst(
                  'Exception: ',
                  '',
                );
      });
    } finally {
      if (mounted) {
        setState(() {
          _isSaving = false;
        });
      }
    }
  }

  // ============================================================
  // BUILD
  // ============================================================

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.background,
        elevation: 0,
        surfaceTintColor: Colors.transparent,
        leading: IconButton(
          onPressed: _isSaving
              ? null
              : () => Navigator.of(context).pop(),
          icon: const Icon(
            Icons.arrow_back_rounded,
            color: AppColors.navy,
          ),
        ),
        title: const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Terima Barang',
              style: TextStyle(
                color: AppColors.navy,
                fontSize: 20,
                fontWeight: FontWeight.w900,
              ),
            ),
            Text(
              'Penerimaan barang baru',
              style: TextStyle(
                color: AppColors.textSecondary,
                fontSize: 12,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: SingleChildScrollView(
                physics:
                    const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.fromLTRB(
                  18,
                  8,
                  18,
                  30,
                ),
                child: Column(
                  crossAxisAlignment:
                      CrossAxisAlignment.start,
                  children: [
                    _buildIntroCard(),

                    const SizedBox(height: 20),

                    const SectionHeader(
                      icon: Icons.storefront_rounded,
                      title: 'Pengirim',
                      subtitle:
                          'Cari pengirim atau tambahkan baru',
                    ),

                    const SizedBox(height: 12),

                    _buildSenderSection(),

                    const SizedBox(height: 24),

                    const SectionHeader(
                      icon: Icons.person_rounded,
                      title: 'Penerima',
                      subtitle:
                          'Informasi penerima barang',
                    ),

                    const SizedBox(height: 12),

                    _buildReceiverSection(),

                    const SizedBox(height: 24),

                    const SectionHeader(
                      icon: Icons.local_shipping_rounded,
                      title: 'Pengiriman',
                      subtitle:
                          'Tujuan dan informasi perjalanan',
                    ),

                    const SizedBox(height: 12),

                    _buildShippingSection(),

                    if (_errorMessage != null) ...[
                      const SizedBox(height: 20),
                      InfoBanner(
                        variant: InfoBannerVariant.error,
                        message: _errorMessage!,
                        onDismiss: () {
                          setState(() {
                            _errorMessage = null;
                          });
                        },
                      ),
                    ],
                  ],
                ),
              ),
            ),

            _buildSaveButton(),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // INTRO
  // ============================================================

  Widget _buildIntroCard() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            AppColors.navy,
            AppColors.blue,
            AppColors.cyan,
          ],
        ),
        borderRadius: BorderRadius.circular(26),
        boxShadow: [
          BoxShadow(
            color: AppColors.blue.withOpacity(0.20),
            blurRadius: 22,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 58,
            height: 58,
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.15),
              borderRadius: BorderRadius.circular(18),
            ),
            child: const Icon(
              Icons.inventory_2_rounded,
              color: Colors.white,
              size: 30,
            ),
          ),
          const SizedBox(width: 16),
          const Expanded(
            child: Column(
              crossAxisAlignment:
                  CrossAxisAlignment.start,
              children: [
                Text(
                  'Penerimaan Baru',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                SizedBox(height: 5),
                Text(
                  'Nomor resi akan dibuat otomatis oleh sistem.',
                  style: TextStyle(
                    color: Colors.white70,
                    fontSize: 12,
                    height: 1.4,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // SENDER
  // ============================================================

  Widget _buildSenderSection() {
    return AppCard(
      child: SearchPickField<SenderModel>(
        controller: _senderController,
        label: 'Cari Pengirim',
        hint: 'Ketik nama pengirim...',
        enabled: !_isSaving,
        onSearch: SenderService.searchSenders,
        itemLabel: (sender) => sender.name,
        itemSubtitle: (sender) => sender.phone,
        selected: _selectedSender,
        onSelected: _selectSender,
        onClear: _clearSender,
        selectedBuilder: (context, sender) =>
            _buildSelectedSender(sender),
        addNewLabel: 'Tambah Pengirim Baru',
        onAddNew: _showCreateSenderDialog,
      ),
    );
  }

  Widget _buildSelectedSender(SenderModel sender) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [
            Color(0xFFEAF2FF),
            Color(0xFFE8FBFF),
          ],
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: AppColors.blue.withOpacity(0.15),
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  AppColors.blue,
                  AppColors.cyan,
                ],
              ),
              shape: BoxShape.circle,
            ),
            child: const Icon(
              Icons.business_rounded,
              color: Colors.white,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment:
                  CrossAxisAlignment.start,
              children: [
                Text(
                  sender.name,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: AppColors.textPrimary,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                if (sender.phone != null) ...[
                  const SizedBox(height: 3),
                  Text(
                    sender.phone!,
                    style: const TextStyle(
                      color: AppColors.textSecondary,
                      fontSize: 12,
                    ),
                  ),
                ],
              ],
            ),
          ),
          const Icon(
            Icons.check_circle_rounded,
            color: AppColors.green,
          ),
        ],
      ),
    );
  }

  // ============================================================
  // RECEIVER
  // ============================================================

  Widget _buildReceiverSection() {
    return AppCard(
      child: Column(
        children: [
          AppTextField(
            controller: _receiverNameController,
            label: 'Nama Penerima',
            hint: 'Masukkan nama penerima',
            icon: Icons.person_outline_rounded,
            enabled: !_isSaving,
          ),
          const SizedBox(height: 14),
          AppTextField(
            controller: _receiverPhoneController,
            label: 'No. HP',
            hint: 'Masukkan nomor HP',
            icon: Icons.phone_outlined,
            keyboardType: TextInputType.phone,
            enabled: !_isSaving,
          ),
          const SizedBox(height: 14),
          AppTextField(
            controller: _destinationAddressController,
            label: 'Alamat Penerima',
            hint: 'Masukkan alamat lengkap',
            icon: Icons.location_on_outlined,
            maxLines: 3,
            enabled: !_isSaving,
          ),
        ],
      ),
    );
  }

  // ============================================================
  // SHIPPING
  // ============================================================

  Widget _buildShippingSection() {
    return AppCard(
      child: Column(
        children: [
          AppTextField(
            controller: _destinationController,
            label: 'Tujuan',
            hint: 'Contoh: Jakarta',
            icon: Icons.place_outlined,
            enabled: !_isSaving,
          ),
          const SizedBox(height: 14),
          AppTextField(
            controller: _routeController,
            label: 'Route',
            hint: 'Contoh: Bandung → Jakarta',
            icon: Icons.alt_route_rounded,
            enabled: !_isSaving,
          ),
          const SizedBox(height: 14),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(15),
            decoration: BoxDecoration(
              color: AppColors.fieldFill,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: const Color(0xFFE4E9F2),
              ),
            ),
            child: const Row(
              children: [
                Icon(
                  Icons.inventory_2_outlined,
                  color: AppColors.violet,
                ),
                SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment:
                        CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Jenis Paket',
                        style: TextStyle(
                          color: AppColors.textSecondary,
                          fontSize: 11,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      SizedBox(height: 3),
                      Text(
                        'Akan dihubungkan ke Package Type',
                        style: TextStyle(
                          color: AppColors.textPrimary,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ],
                  ),
                ),
                Icon(
                  Icons.arrow_forward_ios_rounded,
                  size: 15,
                  color: AppColors.textSecondary,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // SAVE BUTTON
  // ============================================================

  Widget _buildSaveButton() {
    return Container(
      padding: const EdgeInsets.fromLTRB(
        18,
        12,
        18,
        16,
      ),
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: AppColors.navy.withOpacity(0.08),
            blurRadius: 20,
            offset: const Offset(0, -5),
          ),
        ],
      ),
      child: PrimaryButton(
        label: 'Simpan Penerimaan',
        loadingLabel: 'Menyimpan...',
        isLoading: _isSaving,
        icon: Icons.check_circle_outline_rounded,
        onPressed: _saveReceiving,
      ),
    );
  }
}
