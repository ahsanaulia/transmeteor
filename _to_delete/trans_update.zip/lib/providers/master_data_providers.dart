import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../models/employee_role_model.dart';
import '../models/item_type_model.dart';
import '../models/package_type_model.dart';
import '../models/pricing_type_model.dart';
import '../models/route_pricing_model.dart';
import '../models/sender_model.dart';
import '../services/item_type_service.dart';
import '../services/package_type_service.dart';
import '../services/pricing_type_service.dart';
import '../services/role_service.dart';
import '../services/route_pricing_service.dart';
import '../services/sender_service.dart';

/// Provider untuk data master yang dipakai berulang kali di banyak
/// halaman (dropdown/picker item type, pricing type, package type, dst).
///
/// Riverpod meng-cache hasilnya -- begitu satu halaman memanggil salah
/// satu provider ini, halaman lain yang butuh data yang sama tidak
/// fetch ulang ke Supabase selama provider-nya belum di-invalidate.
///
/// Kalau datanya baru saja diubah (habis create/update/deactivate di
/// halaman CRUD modul terkait), panggil `ref.invalidate(xxxProvider)`
/// supaya halaman lain ikut melihat data terbaru.

final sendersProvider = FutureProvider<List<SenderModel>>((ref) {
  return SenderService.getSenders();
});

final itemTypesProvider = FutureProvider<List<ItemTypeModel>>((ref) {
  return ItemTypeService.getItemTypes();
});

final pricingTypesProvider = FutureProvider<List<PricingTypeModel>>((ref) {
  return PricingTypeService.getPricingTypes();
});

final packageTypesProvider = FutureProvider<List<PackageTypeModel>>((ref) {
  return PackageTypeService.getPackageTypes();
});

final routePricingsProvider = FutureProvider<List<RoutePricingModel>>((ref) {
  return RoutePricingService.getRoutePricings();
});

final employeeRolesProvider = FutureProvider<List<EmployeeRoleModel>>((ref) {
  return RoleService.getRoles();
});
