import '../core/services/supabase_service.dart';

import '../models/receiving_model.dart';
import '../models/receiving_detail_model.dart';

class ReceivingService {
  static final _client = SupabaseService.client;

  // ============================================================
  // RECEIVING
  // ============================================================

  /// Mengambil semua receiving.
  static Future<List<ReceivingModel>> getReceivings() async {
    final response = await _client
        .from('receiving')
        .select()
        .order('created_at', ascending: false);

    return (response as List)
        .map(
          (data) => ReceivingModel.fromMap(
            Map<String, dynamic>.from(data),
          ),
        )
        .toList();
  }

  /// Mengambil satu receiving berdasarkan ID.
  static Future<ReceivingModel?> getReceivingById(
    String id,
  ) async {
    final response = await _client
        .from('receiving')
        .select()
        .eq('id', id)
        .maybeSingle();

    if (response == null) {
      return null;
    }

    return ReceivingModel.fromMap(
      Map<String, dynamic>.from(response),
    );
  }

  /// Mengambil receiving berdasarkan nomor resi.
  static Future<ReceivingModel?> getReceivingByReceiptNumber(
    String receiptNumber,
  ) async {
    final response = await _client
        .from('receiving')
        .select()
        .eq('receipt_number', receiptNumber)
        .maybeSingle();

    if (response == null) {
      return null;
    }

    return ReceivingModel.fromMap(
      Map<String, dynamic>.from(response),
    );
  }

  /// Membuat receiving baru.
  ///
  /// Nomor resi dibuat otomatis oleh Supabase.
  /// Flutter tidak mengirim receipt_number.
  static Future<ReceivingModel> createReceiving({
    required String senderId,
    required String receiverName,
    String? receiverPhone,
    required String packageTypeId,
    required String destination,
    String? destinationAddress,
    DateTime? receivedAt,
    DateTime? expectedArrivalAt,
    required String receivedBy,
    String? route,
    String? routePricingId,
  }) async {
    final data = {
      'sender_id': senderId,
      'receiver_name': receiverName,
      'receiver_phone': receiverPhone,
      'package_type_id': packageTypeId,
      'destination': destination,
      'destination_address': destinationAddress,
      'received_at':
          (receivedAt ?? DateTime.now()).toIso8601String(),
      'expected_arrival_at':
          expectedArrivalAt?.toIso8601String(),
      'received_by': receivedBy,
      'status': 'RECEIVED',
      'route': route,
      'route_pricing_id': routePricingId,
    };

    final response = await _client
        .from('receiving')
        .insert(data)
        .select()
        .single();

    return ReceivingModel.fromMap(
      Map<String, dynamic>.from(response),
    );
  }

  /// Mengubah status receiving.
  static Future<void> updateReceivingStatus({
    required String receivingId,
    required String status,
  }) async {
    await _client
        .from('receiving')
        .update({
          'status': status,
          'updated_at': DateTime.now().toIso8601String(),
        })
        .eq('id', receivingId);
  }

  /// Menghapus receiving.
  ///
  /// Detail receiving akan ikut terhapus karena
  /// foreign key receiving_details menggunakan ON DELETE CASCADE.
  static Future<void> deleteReceiving(
    String receivingId,
  ) async {
    await _client
        .from('receiving')
        .delete()
        .eq('id', receivingId);
  }

  // ============================================================
  // RECEIVING DETAILS
  // ============================================================
  //
  // NOTE: total_quantity & total_price pada tabel `receiving` dihitung
  // ulang otomatis oleh trigger Postgres `trg_receiving_details_recalculate`
  // (lihat supabase/receiving_totals_trigger.sql) setiap ada perubahan
  // di tabel ini. Service di sini tidak perlu (dan tidak boleh) menghitung
  // ulang total secara manual dari Flutter -- supaya totalnya tetap benar
  // walaupun datanya diubah dari luar aplikasi.

  /// Mengambil semua detail dari satu receiving.
  static Future<List<ReceivingDetailModel>>
      getReceivingDetails(
    String receivingId,
  ) async {
    final response = await _client
        .from('receiving_details')
        .select()
        .eq('receiving_id', receivingId)
        .order('created_at', ascending: true);

    return (response as List)
        .map(
          (data) => ReceivingDetailModel.fromMap(
            Map<String, dynamic>.from(data),
          ),
        )
        .toList();
  }

  /// Mengambil satu detail berdasarkan ID.
  static Future<ReceivingDetailModel?> getReceivingDetailById(
    String detailId,
  ) async {
    final response = await _client
        .from('receiving_details')
        .select()
        .eq('id', detailId)
        .maybeSingle();

    if (response == null) {
      return null;
    }

    return ReceivingDetailModel.fromMap(
      Map<String, dynamic>.from(response),
    );
  }

  /// Menambahkan detail barang ke receiving.
  static Future<ReceivingDetailModel> createReceivingDetail({
    required String receivingId,
    required String itemCode,
    required String itemTypeId,
    required String pricingTypeId,
    required String itemName,
    required double quantity,
    required String quantityUnit,
    double? weightKg,
    double? lengthCm,
    double? widthCm,
    double? heightCm,
    double? volumeM3,
    double? unitPrice,
    double? totalPrice,
  }) async {
    final data = {
      'receiving_id': receivingId,
      'item_code': itemCode,
      'item_type_id': itemTypeId,
      'pricing_type_id': pricingTypeId,
      'item_name': itemName,
      'quantity': quantity,
      'quantity_unit': quantityUnit,
      'weight_kg': weightKg,
      'length_cm': lengthCm,
      'width_cm': widthCm,
      'height_cm': heightCm,
      'volume_m3': volumeM3,
      'unit_price': unitPrice,
      'total_price': totalPrice,
    };

    final response = await _client
        .from('receiving_details')
        .insert(data)
        .select()
        .single();

    return ReceivingDetailModel.fromMap(
      Map<String, dynamic>.from(response),
    );
  }

  /// Mengubah detail barang.
  static Future<ReceivingDetailModel>
      updateReceivingDetail({
    required String detailId,
    required String itemCode,
    required String itemTypeId,
    required String pricingTypeId,
    required String itemName,
    required double quantity,
    required String quantityUnit,
    double? weightKg,
    double? lengthCm,
    double? widthCm,
    double? heightCm,
    double? volumeM3,
    double? unitPrice,
    double? totalPrice,
  }) async {
    final data = {
      'item_code': itemCode,
      'item_type_id': itemTypeId,
      'pricing_type_id': pricingTypeId,
      'item_name': itemName,
      'quantity': quantity,
      'quantity_unit': quantityUnit,
      'weight_kg': weightKg,
      'length_cm': lengthCm,
      'width_cm': widthCm,
      'height_cm': heightCm,
      'volume_m3': volumeM3,
      'unit_price': unitPrice,
      'total_price': totalPrice,
      'updated_at': DateTime.now().toIso8601String(),
    };

    final response = await _client
        .from('receiving_details')
        .update(data)
        .eq('id', detailId)
        .select()
        .single();

    return ReceivingDetailModel.fromMap(
      Map<String, dynamic>.from(response),
    );
  }

  /// Menghapus detail barang.
  static Future<void> deleteReceivingDetail(
    String detailId,
  ) async {
    await _client
        .from('receiving_details')
        .delete()
        .eq('id', detailId);
  }
}
