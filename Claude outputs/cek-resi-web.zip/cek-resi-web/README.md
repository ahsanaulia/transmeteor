# Website "Cek Resi" (terpisah dari app utama)

Website statis (HTML/CSS/JS polos, TIDAK PAKAI Flutter, TIDAK PAKAI build
tool apa pun) untuk pelanggan mengecek status kirimannya sendiri --
Nomor Resi / Nomor Buku -> status (diterima / dimuat / berangkat / tiba)
+ posisi kendaraan di peta. Sengaja dibuat TERPISAH TOTAL dari project
Flutter "trans" (domain/link berbeda), supaya publik tidak pernah punya
jalur apa pun menuju app utama (login, data internal, dll).

Isi folder ini:

- `index.html` -- halaman (satu-satunya halaman).
- `style.css` -- styling (warna disamakan dengan app Flutter).
- `app.js` -- logic (panggil Supabase, render hasil, peta).
- `config.js` -- **WAJIB diisi dulu sebelum deploy** (lihat langkah 1).

## 1. Isi `config.js`

Buka `config.js`, isi 2 nilai dari project Supabase yang SAMA dengan yang
dipakai app Flutter "trans" (karena data resi memang ada di situ):

1. Buka [app.supabase.com](https://app.supabase.com) -> pilih project -> **Project Settings** -> **API**.
2. Copy **Project URL** -> paste ke `SUPABASE_URL`.
3. Copy key **anon / public** (BUKAN `service_role`) -> paste ke `SUPABASE_ANON_KEY`.

```js
window.CEK_RESI_CONFIG = {
  SUPABASE_URL: 'https://abcdefgh.supabase.co',
  SUPABASE_ANON_KEY: 'eyJhbGciOi....',
};
```

Anon key AMAN dipasang di website publik -- key ini memang didesain untuk
dipasang di sisi browser/client. Lihat bagian **Keamanan** di bawah untuk
penjelasan & cara memastikannya benar-benar aman di project Anda.

## 2. Pastikan 2 fungsi database ini sudah ada di Supabase

Website ini HANYA memanggil 2 *database function* (RPC) berikut, yang
seharusnya SUDAH dibuat sebelumnya lewat Supabase SQL Editor (file-nya
ada di project Flutter "trans", bukan di folder ini):

- `track_shipment(p_search text)`
- `get_public_company_info()`

Keduanya sudah di-"grant execute" ke role `anon` (artinya BISA dipanggil
tanpa login). Kalau belum pernah dijalankan, jalankan dulu file
`add_track_shipment_rpc.sql` dan `add_public_company_info_rpc.sql` di
Supabase SQL Editor project "trans" Anda.

## 3. Coba dulu di komputer sendiri (opsional)

Tidak butuh install apa pun -- buka `index.html` langsung di browser
(double-click), atau kalau mau lebih mirip production, jalankan server
statis sederhana dari folder ini:

```bash
# Python (biasanya sudah ada di Mac/Linux):
python3 -m http.server 8080
# lalu buka http://localhost:8080 di browser
```

## 4. Deploy ke internet (Netlify -- paling mudah, GRATIS)

**Cara paling simpel -- drag & drop (tanpa akun GitHub):**

1. Buka [app.netlify.com/drop](https://app.netlify.com/drop) (boleh daftar
   akun gratis dulu kalau belum punya).
2. Drag seluruh folder `cek-resi-web` ini (isinya: `index.html`,
   `style.css`, `app.js`, `config.js`, **`_redirects`**) ke halaman itu.
   File `_redirects` WAJIB ikut terupload (lihat bagian "Link langsung
   ke 1 nomor resi" di bawah) -- kalau sebelumnya sudah pernah deploy
   TANPA file ini, ulangi drag & drop supaya file itu ikut masuk.
3. Netlify otomatis deploy & kasih link publik, contoh:
   `https://cek-resi-trans-xyz123.netlify.app`.
4. (Opsional) klik **Site settings -> Change site name** untuk ganti jadi
   nama yang lebih mudah diingat, misal `cek-resi-trans.netlify.app`.
5. Setiap kali mau update isi website (misal ganti warna/teks), ulangi
   drag & drop folder yang sudah diedit ke situs yang sama (Netlify akan
   tanya "deploy baru?" -- pilih Ya/ganti versi lama).

**Alternatif lain (kalau mau yang lebih permanen/auto-update dari Git):**

- **Netlify via GitHub**: push folder ini ke sebuah repo GitHub, lalu di
  Netlify pilih "Import from Git" -> pilih repo itu -> Deploy. Build
  command dikosongkan saja (tidak ada proses build, murni file statis),
  publish directory diisi `.` (folder ini sendiri).
- **Vercel**: [vercel.com](https://vercel.com) -> New Project -> import
  folder/repo ini -> Framework Preset pilih "Other" -> Deploy.
- **GitHub Pages**: push ke repo GitHub -> Settings -> Pages -> pilih
  branch & folder root -> Save. Linknya bentuk
  `https://<username>.github.io/<repo>/`.

Ketiganya GRATIS untuk pemakaian website statis sederhana seperti ini.

**Catatan `_redirects` di hosting selain Netlify**: file `_redirects`
format ini SPESIFIK Netlify. Kalau pindah ke:
- **Vercel**: tambahkan `vercel.json` berisi
  `{"rewrites": [{"source": "/(.*)", "destination": "/index.html"}]}`.
- **GitHub Pages**: tidak mendukung rewrite server-side -- link
  `{url}/{no resi}` TIDAK akan jalan di GitHub Pages (tetap 404), cuma
  format query string `{url}/?resi={no resi}` yang tetap jalan di sana
  (lihat bagian di bawah).

## 4b. Link langsung ke 1 nomor resi (tanpa customer ketik ulang)

**FITUR (21 Oktober 2026, permintaan user eksplisit)**: supaya customer
yang dikirimi link lewat WhatsApp TIDAK perlu mengetik ulang nomor
resinya sendiri, website ini SEKARANG bisa dibuka langsung ke hasil 1
resi lewat 2 format:

- **Path** (dipakai otomatis oleh app Flutter "trans" di pesan WA):
  `https://cek-resi-trans.netlify.app/RESI000123`
- **Query string** (fallback, jalan di hosting apa pun termasuk GitHub
  Pages): `https://cek-resi-trans.netlify.app/?resi=RESI000123`

Begitu halaman terbuka dengan salah satu format di atas, nomor resinya
otomatis diisi ke kolom pencarian dan langsung di-cari -- customer
tinggal lihat hasilnya. Kalau dibuka tanpa apa-apa di belakang link
(`https://cek-resi-trans.netlify.app`), halaman tetap tampil seperti
biasa (form kosong, customer isi manual) -- perilaku lama TIDAK berubah.

Format **path** ini yang otomatis dipakai app Flutter "trans" (lihat
`receipt_preview_page.dart`) saat menyusun pesan WhatsApp ke tujuan --
TIDAK perlu diatur apa pun lagi di app, cukup pastikan field "Link
Website Cek Resi" di Profil Perusahaan berisi link Netlify (TANPA "/"
di akhir ATAU dengan "/" di akhir, keduanya aman -- kode otomatis
membuang "/" dobel).

## 5. Setelah live, catat linknya di app Admin "trans"

1. Login ke app "trans" sebagai Admin.
2. Buka menu **Profil Perusahaan**.
3. Isi field **"Link Website Cek Resi"** dengan link yang didapat dari
   langkah 4 (misal `https://cek-resi-trans.netlify.app`).
4. Simpan. Link ini otomatis muncul di footer pesan WhatsApp ke tujuan &
   footer cetakan Resi, supaya pelanggan tahu ke mana harus buka untuk
   cek status kirimannya sendiri.

Kalau nanti domain/hosting website ini berubah (misal pindah dari
Netlify ke Vercel), cukup update field itu lagi -- TIDAK perlu build
ulang app Flutter-nya sama sekali.

## Keamanan -- mengapa ini aman walau linknya publik & anon key terlihat di kode

Website ini sengaja dirancang supaya **walaupun semua orang bisa melihat
isi `config.js` lewat "View Source" browser** (termasuk anon key-nya),
mereka TETAP TIDAK BISA mengakses data lain selain yang memang
dimaksudkan publik:

- Website ini TIDAK PERNAH query tabel langsung (`select * from ...`).
  Satu-satunya cara dia bicara ke database adalah lewat 2 *database
  function* (`track_shipment`, `get_public_company_info`) yang
  dijalankan sebagai `SECURITY DEFINER` -- function inilah yang
  menentukan field APA SAJA yang boleh keluar (lihat isi
  `jsonb_build_object(...)` di SQL-nya), BUKAN anon key yang menentukan.
- Anon key HANYA bisa menjalankan function yang memang di-"grant
  execute" ke role `anon` secara eksplisit lewat
  `grant execute on function ... to anon;` -- kedua function di atas
  SUDAH digrant begini, tapi fungsi-fungsi/tabel LAIN di database Anda
  TIDAK otomatis ikut terbuka hanya karena satu function digrant.

**Yang TETAP perlu Anda pastikan sendiri di dashboard Supabase** (di luar
kode ini, karena ini soal konfigurasi project, bukan soal website ini):

1. Buka **Database -> Roles** atau jalankan query ini di SQL Editor
   untuk melihat privilege role `anon` saat ini:
   ```sql
   select grantee, table_schema, table_name, privilege_type
   from information_schema.role_table_grants
   where grantee = 'anon';
   ```
   Idealnya hasilnya KOSONG atau cuma tabel yang memang sengaja ingin
   publik (seharusnya tidak ada untuk app ini). Kalau ada baris SELECT
   ke tabel seperti `receiving`/`shipments`/`employees`/dst muncul di
   sini, itu artinya anon key BISA baca tabel itu LANGSUNG (lewat
   REST API Supabase, bukan lewat website ini) TERLEPAS dari RLS kalau
   RLS belum diaktifkan di tabel itu -- ini risiko yang SUDAH ADA
   SEBELUM website ini dibuat (bukan disebabkan website ini), tapi jadi
   lebih penting untuk dibereskan begitu ada website publik yang
   menyertakan anon key di kodenya.
2. Kalau ragu, aktifkan **Row Level Security (RLS)** di semua tabel yang
   berisi data internal (lewat **Database -> Tables -> (nama tabel) ->
   RLS**), tanpa perlu bikin policy apa pun untuk `anon` (artinya: RLS
   aktif tapi tidak ada policy = default TOLAK semua akses anon ke tabel
   itu lewat REST API) -- function `SECURITY DEFINER` seperti
   `track_shipment` TETAP bisa jalan normal walau RLS aktif, karena
   function itu jalan dengan privilege pemiliknya, bukan privilege
   pemanggil (anon).
3. JANGAN PERNAH taruh **service_role key** di website ini atau di mana
   pun yang bisa diakses browser -- key itu bypass semua RLS/grant, beda
   total dengan anon key.

## Yang TIDAK ada di website ini (sengaja)

- Tidak ada form login/akun apa pun.
- Tidak ada link/jalur menuju app Flutter "trans" (admin, staff, dsb).
- Tidak ada query/tulis data apa pun -- murni BACA (read-only) lewat 2
  RPC di atas.
